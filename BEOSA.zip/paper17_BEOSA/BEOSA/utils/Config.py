# -*- coding: utf-8 -*-
"""
Created on Wed Aug 31 08:07:04 2022

@author: Oyelade
"""

#Number of iterations
MaxIter = 50

#Initialization of accumulative list storage for fit and cost values
method_fit_pop=None
method_cost_pop=None

#Number of runnings for each experimentation of the algorithms
number_of_runs=1

#Variouse population sizes you want to investigate with
p_size = [25, 50, 75, 100] #25, 50, 75, 100, 

#Store results dir
result_dir='./results/'
dataset_dir='datasets/'
runs_dir='runs/'
bests_dir='bests/'
accuracy_dir='accuracy/'
fitness_dir='fitness/'
cost_dir='cost/'
metrics_dir='metrics/'
popsize_accuracy_dir='popsizeacc/'

#Classifiers
classifiers=['knn', 'rf', 'mlp', 'dt', 'svm', 'gnb']
#All datasets to be used for experimentation
    
#All algorithms to be experimented with
algorithms=[
            'BSFO', #'BSNDO', 
            #'BEOSA', 'BIEOSA', 'BDMO', 'BSNDO',
            #'BPSO', 'BWOA', 'BGWO', 'BSFO'
        ]

datasetlist = [ 
        
                #'iris.csv' #(BSFO, BSNDO)
                #'Lung.csv' (BSFO)
                #'Prostrate.csv' (BWOA, BPSO[3], BSFO, BGWO)
                #'Colon.csv' (BFSO)
                #'Leukemia.csv' (BSFO)
    
                #"BreastEW.csv", 
                #"BreastCancer.csv",
                #"CongressEW.csv", 
                #"Exactly.csv", 
                #"Exactly2.csv", 
                #"HeartEW.csv", 
    
                #^^^^"Ionosphere.csv",
                #^^^^"M-of-n.csv", 
                "PenglungEW.csv", #(BPSO[100])
                #^^^^"Sonar.csv",
                #^^^^"SpectEW.csv", 
                #^^^^"Tic-tac-toe.csv", 
                #^^^^"Lymphography.csv", 
                
                #^^^^"Vote.csv", 
                #^^^^"Wine.csv", 
                #"Zoo.csv", #^^^^
                #"KrVsKpEW.csv", #BSFO([75, 100])
                #"WaveformEW.csv" #BGWO (3), BIEOSA (3), BSNDO,BPSO,BWOA,BSFO
              ]
    